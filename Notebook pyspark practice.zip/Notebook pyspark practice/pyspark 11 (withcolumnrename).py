# Databricks notebook source
# MAGIC %md
# MAGIC Change existing column name in dataframe using 𝘄𝗶𝘁𝗵𝗖𝗼𝗹𝘂𝗺𝗻𝗥𝗲𝗻𝗮𝗺𝗲𝗱() function in pyspark.
# MAGIC
# MAGIC [A DataFrame is an immutable(Can't change) distributed collection of data.]
# MAGIC

# COMMAND ----------

data = [(1,'Maheer','2000'),(2,'Wafa','3000')]
columns = ['id','name','salary']
df = spark.createDataFrame(data = data,schema=columns)

# COMMAND ----------

help(df.withColumnRenamed)

# COMMAND ----------

df1=df.withColumnRenamed(existing='salary',new='salary_amount')
df1.show()

# COMMAND ----------

