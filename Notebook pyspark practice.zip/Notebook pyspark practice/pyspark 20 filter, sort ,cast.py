# Databricks notebook source
#𝗮𝗹𝗶𝗮𝘀(), 𝗮𝘀𝗰(), 𝗱𝗲𝘀𝗰(), 𝗰𝗮𝘀𝘁() & 𝗹𝗶𝗸𝗲() functions which are useful while working with dataframe columns.

data = [(1,'anil',2000),(2,'sandeep',3000),(3,'arun',4000)]
schema = ['id', 'name', 'salary']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

# alias() - Provides alias to the column

df1 = df.select(df.id.alias('emp_id'),df.name.alias('emp_name'),df.salary.alias('emp_salary'))
df1.show()

# COMMAND ----------

# asc() & desc() - Sort columns ascending or descending order

df.sort(df.name.asc()).show()
df.sort(df.name.desc()).show()

# COMMAND ----------

# cast() - Convert the datatype

df.printSchema()

df2 = df.select(df.id,df.name,df.salary.cast('int'))
df2.printSchema()

# COMMAND ----------

# like() - Similar to SQL LIKE expression

df.filter(df.name.like('a%')).show()

df.filter(df.name.like('s%')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC 𝗳𝗶𝗹𝘁𝗲𝗿() and 𝘄𝗵𝗲𝗿𝗲() function in Pyspark helps to filter rows in dataframe.
# MAGIC - Pyspark filter() function is used to filter the rows from DataFrame based on the given condition or SQL expression.
# MAGIC - You can also use where() clause instead of the filter() if you are coming from an SQL background, both these functions operate exactly the same.

# COMMAND ----------

data = [(1,'anil','male',2000),(2,'sandeep','male',3000),(3,'riya','female',4000)]
schema = ['id','name','gender','salary']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

df.filter(df.gender == 'male').show()


# COMMAND ----------

df.filter("gender =='male'").show()


# COMMAND ----------

df.where(df.gender=='male').show()

# COMMAND ----------

# For multiple conditions -

df.where((df.gender=='male')&(df.salary==2000)).show()

# COMMAND ----------

# Or
df.filter((df.gender=='male')|(df.salary==3000)).show()

# COMMAND ----------

df.where(("gender=='male'") and ("salary==2000")).show()

# COMMAND ----------

# Or
df.filter(("gender=='male'") or ("salary==3000")).show()

# COMMAND ----------

