# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC 𝘄𝗵𝗲𝗻() & 𝗼𝘁𝗵𝗲𝗿𝘄𝗶𝘀𝗲() functions
# MAGIC
# MAGIC It is similar to SQL Case statement, executes sequence of expressions until it matches the condition and returns a value when match.

# COMMAND ----------

data = [(1,'anil','M',2000),(2,'riya','F',3000),(2,'sandeep','',4000)]
schema = ['id','name','gender','salary']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df.select(df.gender,df.salary,,when(df.name=="%i%",False)).show()

# COMMAND ----------

from pyspark.sql.functions import when
df1=df.select(df.id,df.name,when(condition=df.gender=='M',value='MALE')\
              .when(condition=df.gender=='F',value='Female')\
              .otherwise('Unknown').alias('gender'),df.salary)
df1.show()

# COMMAND ----------

