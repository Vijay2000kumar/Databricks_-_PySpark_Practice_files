# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC 𝗦𝘁𝗿𝘂𝗰𝘁𝗧𝘆𝗽𝗲() and 𝗦𝘁𝗿𝘂𝗰𝘁𝗙𝗶𝗲𝗹𝗱() Classes to create schema for dataframe and create complex columns like nested struct, array, and map columns.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType
data = [(1,'Maheer',3000),(1,'Wafa',4000)]
schema = StructType([StructField(name='id',dataType=IntegerType()),\
          StructField(name='name',dataType=StringType()),\
          StructField(name='salary',dataType=IntegerType())])

df = spark.createDataFrame(data=data,schema=schema)
df.show()
df.printSchema()

# COMMAND ----------

# Create complex column

from pyspark.sql.types import StructType, StructField, IntegerType, StringType
data = [(1,('Maheer','Shaik'),3000),(1,('Wafa','Shaik'),4000)]

# COMMAND ----------

Sub_Name = StructType([\
            StructField(name='firstname',dataType=StringType()),\
            StructField(name='lastname',dataType=StringType())])

schema = StructType([StructField(name='id',dataType=IntegerType()),\
          StructField(name='name',dataType=Sub_Name),\
          StructField(name='salary',dataType=IntegerType())])

# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.show()
df.printSchema()

# COMMAND ----------

