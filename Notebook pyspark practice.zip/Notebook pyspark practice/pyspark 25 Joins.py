# Databricks notebook source
# MAGIC %md
# MAGIC # 𝗶𝗻𝗻𝗲𝗿, 𝗹𝗲𝗳𝘁, 𝗿𝗶𝗴𝗵𝘁, 𝗳𝘂𝗹𝗹 𝗝𝗼𝗶𝗻𝘀
# MAGIC 𝗷𝗼𝗶𝗻() function in pyspark with inner join, left join, right join and full join examples.
# MAGIC

# COMMAND ----------

data1 = [(1,'anil',2000,2),(2,'sandeep',3000,1),(3,'abcd',1000,4)]
schema1 = ['id','name','salary','dep']

data2 = [(1,'IT'),(2,'HR'),(3,'Payroll')]
schema2 = ['id','name']

# COMMAND ----------

empdf = spark.createDataFrame(data1,schema1)
depdf = spark.createDataFrame(data2,schema2)

# COMMAND ----------

empdf.show()
depdf.show()

# COMMAND ----------

depdf.crossjoin(empdf).show()

# COMMAND ----------

#left semi join
empdf.join(depdf,depdf.id==empdf.dep,"semi").show()

# COMMAND ----------

empdf.join(depdf,depdf.id==empdf.dep,"right").show()

# COMMAND ----------

empdf.join(depdf,empdf['id']==depdf['id'],"left").show()

# COMMAND ----------

# Left anti

empdf.join(depdf,empdf.dep==depdf.id,'leftanti').show()

# COMMAND ----------

