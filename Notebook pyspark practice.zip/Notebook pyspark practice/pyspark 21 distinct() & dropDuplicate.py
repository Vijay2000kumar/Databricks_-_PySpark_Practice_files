# Databricks notebook source
# MAGIC %md
# MAGIC 𝗱𝗶𝘀𝘁𝗶𝗻𝗰𝘁() & 𝗱𝗿𝗼𝗽𝗗𝘂𝗽𝗹𝗶𝗰𝗮𝘁𝗲𝘀() functions in PySpark -
# MAGIC - Pyspark distinct() function is used to remove the duplicate rows (all columns).
# MAGIC -dropDuplicates() is used to drop rows based on selected (one or multiple) columns.
# MAGIC - So basically, using these functions we can get distinct rows.

# COMMAND ----------

data = [(1,'anil','male',2000),(2,'sandeep','male',3000),(2,'sandeep','male',3000),(3,'riya','female',4000)]
schema = ['id','name','gender','salary']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

df.distinct().show()

# COMMAND ----------

df.dropDuplicates().show()

# COMMAND ----------

df.dropDuplicates(subset=['gender']).show()

# COMMAND ----------

df.dropDuplicates(subset=['gender','salary']).show()

# COMMAND ----------

df.dropDuplicates(subset=['salary']).show()

# COMMAND ----------

