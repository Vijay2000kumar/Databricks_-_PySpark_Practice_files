# Databricks notebook source
# MAGIC %md
# MAGIC 𝗽𝗶𝘃𝗼𝘁() function which helps to rotate rows data into columns using PySpark.
# MAGIC - It is aggreation where one of the grouping column values will be converted in indivual columns.

# COMMAND ----------

data = [(1,'anil','male','IT'),\
     (2,'arun','male','IT'),\
(3,'riya','female','HR'),\
(4,'vani','female','IT'),\
(5,'rohi','female','IT'),\
(6,'sandeeep','male','HR'),\
(7,'anurag','male','HR'),\
(8,'pooja','female','IT')]
schema = ['id','name','gender','dep']

df = spark.createDataFrame(data, schema)
df.show()

# COMMAND ----------

df.groupBy('dep','gender').count().show()

# COMMAND ----------

df.groupBy('dep').pivot('gender').count().show()

# COMMAND ----------

# If there is many values and you need specific value in form of column -

df.groupBy('dep').pivot('gender',['male']).count().show()

# COMMAND ----------

df.groupBy('dep').pivot('gender',['male','female']).count().show()

# COMMAND ----------

