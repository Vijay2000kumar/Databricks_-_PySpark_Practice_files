# Databricks notebook source
# MAGIC %md
# MAGIC Pyspark 𝗠𝗮𝗽𝗧𝘆𝗽𝗲() is used to represent map key-value pair similar to python Dictionary (Dict) or like json.

# COMMAND ----------

# MapType column -

data = [('maheer',{'hair':'black','eye':'brown'}),('wafa',{'hair':'black','eye':'blue'})]
schema = ['name', 'properties']

# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.show(truncate=False)
df.printSchema()

# COMMAND ----------

from pyspark.sql.types import MapType,StructField,StructType,StringType,IntegerType
data = [('maheer',{'hair':'black','eye':'brown'}),('wafa',{'hair':'black','eye':'blue'})]
schema = StructType([\
           StructField('name',StringType()),\
           StructField('properties',MapType(keyType=StringType(),valueType=StringType()))
          ])

# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.show(truncate=False)
df.printSchema()

# COMMAND ----------

# Access MapType elements -

df1 = df.withColumn(colName='hair',col=df.properties['hair'])
df1.show(truncate=False)

# COMMAND ----------

df2 = df.withColumn('eye', df1.properties.getItem('eye'))
df2.show(truncate=False)

# COMMAND ----------

# explode()

from pyspark.sql.functions import explode
df1 = df.select('name','properties',explode(df.properties))
df1.show(truncate=False)

# COMMAND ----------

# map_keys()

from pyspark.sql.functions import map_keys
df1 = df.withColumn('keys',map_keys(df.properties))
df1.show(truncate=False)

# COMMAND ----------

# map_values

from pyspark.sql.functions import map_values
df1 = df.withColumn('values',map_values(df.properties))
df1.show(truncate=False)

# COMMAND ----------

