# Databricks notebook source
# MAGIC %md
# MAGIC 𝗥𝗼𝘄() is represented as a record/row in DataFrame,one can create a Row object by using named arguments or create a custom Row like class.
# MAGIC

# COMMAND ----------

# Using Row() index

from pyspark.sql import Row

row = Row('maheer', 2000)

print(row[0] + ' ' + str(row[1]))

# COMMAND ----------

# Using named arguments

from pyspark.sql import Row
row = Row(name = 'maheer',salary=2000)

print(row.name + ' ' + str(row.salary)) 


# COMMAND ----------

# Data in DataFrame represent as Row() -

from pyspark.sql import Row
row1 = Row(name = 'maheer',salary=2000)
row2 = Row(name = 'wafa', salary=3000)
 

# COMMAND ----------

data = [row1, row2]
df = spark.createDataFrame(data)
df.show()
df.printSchema()

# COMMAND ----------

# We can also create a Row() like class -

person = Row('name', 'age')
person1 = person('maheer',30)
person2 = person('wafa',5)

# COMMAND ----------

print(person1.name)
print(person1.age)
print(person2.name)
print(person2.age)

# COMMAND ----------

df = spark.createDataFrame([person1,person2])
df.show()
df.printSchema()

# COMMAND ----------

# We can create nested struct type also using Row() -

data = [Row(name ='maheer',prop =Row(age=30,gender='male')),\
    Row(name='wafa',prop =Row(age=5,gender='male'))]
df = spark.createDataFrame(data)
df.show()
df.printSchema

# COMMAND ----------

help(Row)

# COMMAND ----------

