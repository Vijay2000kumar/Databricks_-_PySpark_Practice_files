# Databricks notebook source
# MAGIC %

# COMMAND ----------

from pyspark.sql.functions import lit
col1 = lit(col='abcd')
print(type(col1))

# COMMAND ----------

from pyspark.sql.functions import lit
data = [('maheer','male', 2000),('wafa', 'male', 4000)]
schema = ['name', 'gender', 'salary']


# COMMAND ----------

df = spark.createDataFrame(data,schema)
df.show()
df.printSchema()

# COMMAND ----------

df1 = df.withColumn('newCol',lit('newColVal'))
df1.show()
df1.printSchema()

# COMMAND ----------

# Access column multiple ways from dataframe

df1.select(df1.name).show()

# COMMAND ----------

#Or
df1.select(df1['name']).show()

# COMMAND ----------

#Or
from pyspark.sql.functions import col
df1.select(col('name')).show()

# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql.types import StructType,StructField,StringType,IntegerType,ArrayType
data = [('maheer','male', 2000,('black','brown')),('wafa', 'male', 4000,('black','blue'))]
propsType = StructType([\
            StructField(name='hair',dataType=StringType()),\
            StructField(name='eye',dataType=StringType())])
schema = StructType([\
          StructField(name='name',dataType=StringType()),\
          StructField(name='gender',dataType=StringType()),\
          StructField(name='salary',dataType=IntegerType()),\
          StructField(name='props',dataType=propsType)])



# COMMAND ----------

df = spark.createDataFrame(data,schema)
df.show()
df.printSchema()


# COMMAND ----------

# Accessing Struct Column

df.select(df.props.eye).show()

# COMMAND ----------

#Or
df.select(df['props.eye']).show()

# COMMAND ----------

#Or
from pyspark.sql.functions import col
df.select(col('props.eye')).show()

# COMMAND ----------

