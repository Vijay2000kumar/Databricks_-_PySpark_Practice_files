# Databricks notebook source
# MAGIC %md
# MAGIC 𝗴𝗿𝗼𝘂𝗽𝗕𝘆() in Pyspark which helps to perform grouping of rows in dataframe.
# MAGIC - Pyspark groupBy() function is used to collect the identical data into groups on DataFrame and perform count(), sum(), avg(), min(), max() funtions on the grouped data. 

# COMMAND ----------

data = [(1,'anil','M',5000,'IT'),\
    (2,'sandeep','M',6000,'IT'),\
    (3,'riya','F',2500,'payroll'),\
    (4,'prteek','M',4000,'HR'),\
    (5,'vani','F',2000,'HR'),\
    (6,'sunil','M',2000,'payroll'),\
    (7,'diksha','F',3000,'IT')]

# COMMAND ----------

schema = ['id','name','gender','salary','dep']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

df1=df.groupBy('dep').count()
df1.show()

# COMMAND ----------

df3=df.groupBy('dep').min('salary')
df3.show()

# COMMAND ----------

df.groupBy('dep').max('salary').show()

# COMMAND ----------

df.groupBy('dep').avg('salary').show()


# COMMAND ----------

df.groupBy('dep','gender').count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC Pyspark Groupby 𝗮𝗴𝗴() is used to calculate more than one aggregate(multiple aggregates) at a time on grouped DataFrame.

# COMMAND ----------

from pyspark.sql.functions import min, max,count

df1 = df.groupBy('dep').agg(count('*').alias('countOfEmps'),\
           max('salary').alias('Max_salary'),\
           min('salary').alias('min_salary'))

df1.show()    

# COMMAND ----------

