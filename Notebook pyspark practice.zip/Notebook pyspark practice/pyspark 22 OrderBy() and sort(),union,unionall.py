# Databricks notebook source
# MAGIC %md
# MAGIC 𝗼𝗿𝗱𝗲𝗿𝗕𝘆() & 𝘀𝗼𝗿𝘁() functions in PySpark -
# MAGIC - You can use either sort() or orderBy() function of Pyspark DataFrame to sort DataFrame by ascending or descending order based on single or multiple columns.
# MAGIC - By default, sorting will happen in ascending order. We cn explicitly mention ascending or descendingusing asc(), desc() functions.

# COMMAND ----------

data = [(1,'anil','M',2000,'IT'),(2,'sandeep','M',4000,'HR'),(3,'riya','F',3000,'payroll'),(4,'sandeep','M',3000,'HR')]
schema = ['id','name','gender','salary','dep']
df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

df.sort('dep').show()
# Or
df.sort(df.dep).show()

# COMMAND ----------

df.orderBy('dep').show()
# Or
df.orderBy(df.dep).show()

# COMMAND ----------

df.sort(df.dep,df.id).show()
# Or
df.sort(df.dep,df.id.asc()).show()

# COMMAND ----------

df.sort(df.dep.desc(),df.id.desc()).show()
# Or
df.orderBy(df.dep.asc(),df.id.desc()).show()

# COMMAND ----------

# MAGIC %md
# MAGIC 𝘂𝗻𝗶𝗼𝗻() & 𝘂𝗻𝗶𝗼𝗻𝗔𝗹𝗹() functions in pyspark used to merge rows from dataframe.
# MAGIC - union() and unionAll() transformations are used to merge two or more DataFrame's of the same schema or structure.
# MAGIC - union() and unionAll() method merges two DataFrames and returns the new DataFrame with all rows from DataFrames regardless of duplicate data.
# MAGIC - To remove duplicates use distinct() function.
# MAGIC P.S- unionAll() is deprecated since Spark “2.0.0” version and replaced with union().
# MAGIC As we know, in SQL languages, Union eliminates the duplicates but UnionAll merges two datasets including duplicate records. But, in PySpark both behave the same and recommend using DataFrame distinct() function to remove duplicate rows.

# COMMAND ----------

data1 = [(1,'anil','Male'),(2,'sandeep','Male')]
schema1 = ['id','name','gender']

data2 = [(3,'riya','Female'),(4,'vani','Female')]
schema2 = ['id','name','gender']


# COMMAND ----------

df1 = spark.createDataFrame(data1,schema1)
df2 = spark.createDataFrame(data2,schema2)
df1.show()
df2.show()

# COMMAND ----------

newDf = df1.union(df2)

newDf.show()

# COMMAND ----------

data1 = [(1,'anil','Male'),(2,'sandeep','Male')]
schema1 = ['id','name','gender']

data2 = [(1,'anil','Male'),(3,'riya','Female'),(4,'vani','Female')]
schema2 = ['id','name','gender']

df1 = spark.createDataFrame(data1,schema1)
df2 = spark.createDataFrame(data2,schema2)

df1.show()
df2.show()

# COMMAND ----------

newDf = df1.union(df2)
newDf.show()

# COMMAND ----------

newDf2 = df1.unionAll(df2)
newDf2.show()

# COMMAND ----------

# distinct()

newDf2 = df1.unionAll(df2)
newDf2.distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC 𝘂𝗻𝗶𝗼𝗻𝗕𝘆𝗡𝗮𝗺𝗲() lets you to merge/union two DataFrames with a different number of columns(different schema) by passing allowMissingColumns with the value true. 
# MAGIC ------------------------

# COMMAND ----------

data1 = [(1,'Anil',27)]
schema1 = ['id','name','age']

data2 = [(1,'Anil',2000)]
schema2 = ['id','name','salary']

# COMMAND ----------

df1 = spark.createDataFrame(data1,schema1)
df2 = spark.createDataFrame(data2,schema2)

df1.show()
df2.show()

# COMMAND ----------

# unionByName()

df1.unionByName(df2,allowMissingColumns=True).show()

# COMMAND ----------

