# Databricks notebook source
# MAGIC %md
# MAGIC 𝘀𝗲𝗹𝗲𝗰𝘁() function in pyspark which helps to select single or multiple columns from dataframe.

# COMMAND ----------

data = [(1,'Anil','male',2000)]
schema = ['id','name','gender','salary']

df = spark.createDataFrame(data,schema)
df.show()

# COMMAND ----------

# Different syntaxes to call columns using SELECT()

df.select('id','name').show()

# COMMAND ----------

# Or
df.select(df.id,df.name).show()

# COMMAND ----------

# Or
df.select(df['id'],df['name']).show()

# COMMAND ----------

# Using col() function

from pyspark.sql.functions import col

df.select(col('id'),col('name')).show()

# COMMAND ----------

# As a list

df.select(['id','name']).show()

# COMMAND ----------

# select all columns

df.select('*').show()

# COMMAND ----------

# Supply the list dynamically to select all columns

df.select([col for col in df.columns]).show()

# COMMAND ----------

