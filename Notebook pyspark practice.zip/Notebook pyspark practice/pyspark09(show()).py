# Databricks notebook source
# MAGIC %md
# MAGIC show() is used to display the contents of the DataFrame in a table row and columns format.

# COMMAND ----------


data=[(1,'dhawedhewdhakedlkkdfdlkfjds;kl'),
      (2,'jdfkldjdalkfjlkksdjfl;lksdfj'),
      (3,'lksdjflkdfjassdklfjdslfjddk'),
      (4,'jdlfkdjfdklfjdslfjdsflsdjfds')]
schema= ['id','name']      


# COMMAND ----------

df=spark.createDataFrame(data=data, schema=schema)
df.show()

# COMMAND ----------

help(df.show())

# COMMAND ----------

#to show full contents of column
df.show(truncate= False)

# COMMAND ----------

#truncate column value to desired length
df.show(truncate=10)

# COMMAND ----------

#control rews to display using (n= )
df.show(n=3,truncate=False)

# COMMAND ----------

#Display content vertically
df.show(n=2,truncate=False,vertical=True)

# COMMAND ----------

