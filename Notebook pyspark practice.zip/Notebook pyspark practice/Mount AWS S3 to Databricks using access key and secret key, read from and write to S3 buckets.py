# Databricks notebook source
# MAGIC %md
# MAGIC I will talk about
# MAGIC
# MAGIC How to create an access key and secret key for Databricks in AWS?
# MAGIC How to mount Databricks to AWS S3 bucket?
# MAGIC How to read CSV files from the mounted AWS S3 bucket?
# MAGIC How to write data from Databricks to AWS S3 bucket?
# MAGIC
# MAGIC link-https://medium.com/grabngoinfo/databricks-mount-to-aws-s3-and-import-data-4100621a63fd
# MAGIC
# MAGIC steps i follow-
# MAGIC Step 1: Create AWS Access Key And Secret Key For Databricks
# MAGIC Step 2: Upload AWS Credential File To Databricks
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC /FileStore/tables/last_aws_user_accessKeys.csv
# MAGIC

# COMMAND ----------

# Check the contents in tables folder
dbutils.fs.ls('/FileStore/tables/last_aws_user_accessKeys.csv')

# COMMAND ----------

# pyspark functions
from pyspark.sql.functions import *
# URL processing
import urllib

# COMMAND ----------

# Define file type
file_type = 'csv'
# Whether the file has a header
first_row_is_header = 'true'
# Delimiter used in the file
delimiter = ','
# Read the CSV file to spark dataframe
aws_keys_df = spark.read.format(file_type)\
.option('header', first_row_is_header)\
.option('sep', delimiter)\
.load('/FileStore/tables/last_aws_user_accessKeys.csv')

# COMMAND ----------

aws_keys_df.columns

# COMMAND ----------

# MAGIC %md
# MAGIC Step 3: Mount S3 Bucket To Databricks

# COMMAND ----------

# Get the AWS access key and secret key from the spark dataframe
ACCESS_KEY = aws_keys_df.select('Access key ID').take(1)[0]['Access key ID']
SECRET_KEY = aws_keys_df.select('Secret access key').take(1)[0]['Secret access key']

# COMMAND ----------

# Encode the secrete key
ENCODED_SECRET_KEY = urllib.parse.quote(string=SECRET_KEY, safe="")

# COMMAND ----------

# AWS S3 bucket name
AWS_S3_BUCKET = "vijay-data-bucket"
# Mount name for the bucket
MOUNT_NAME = "/mnt/last1-user-mount"
# Source url
SOURCE_URL = "s3a://%s:%s@%s" %(ACCESS_KEY, ENCODED_SECRET_KEY, AWS_S3_BUCKET)

# COMMAND ----------

# Mount the drive
dbutils.fs.mount(SOURCE_URL, MOUNT_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC Step 4: Read Data From The Mounted S3 Bucket

# COMMAND ----------

# MAGIC %fs ls '/mnt/last1-user-mount'

# COMMAND ----------

# File location and type
file_location = "/mnt/last1-user-mount/StudentsPerformance.csv"
file_type = "csv"
# CSV options
infer_schema = "true"
first_row_is_header = "true"
delimiter = ","
# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
.option("inferschema", infer_schema) \
.option("header", first_row_is_header) \
.option("sep", delimiter) \
.load(file_location)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Step 5: Querying the data
# MAGIC Now that we created our DataFrame. We can query it. For instance, you can select some particular columns to select and display within Databricks.

# COMMAND ----------

df.printSchema()

# COMMAND ----------

#create a temporary view
df.createOrReplaceTempView("TEMP_VIEW_of_student")


# COMMAND ----------

df.withColumnRenamed('math score','math_score').show()

# COMMAND ----------

# MAGIC %sql
# MAGIC select gender, lunch, `race/ethnicity` from TEMP_VIEW_of_student
# MAGIC

# COMMAND ----------

df.filter(df['test preparation course'] =='none').count()

# COMMAND ----------

#We can save data as a table in Parquet format on Databricks for future access.
# Allow creating table using non-emply location
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
# Save table
df.write.format("parquet").saveAsTable('Student_mount_table')

# COMMAND ----------

# Remove the file if it was saved before
#dbutils.fs.rm(‘/mnt/crypto-price-prediction/g-research-crypto-forecasting/demo_example’, True)
# Save to the mounted S3 bucket
#df.write.save(f’/mnt/crypto-price-prediction/g-research-crypto-forecasting/demo_example’, format=’csv’)
# Check if the file was saved successfulydisplay(dbutils.fs.ls(“/mnt/crypto-price-prediction/g-research-crypto-forecasting/demo_example”))

# COMMAND ----------

# Unmount S3 bucket
dbutils.fs.unmount("/mnt/last1-user-mount")

# COMMAND ----------

