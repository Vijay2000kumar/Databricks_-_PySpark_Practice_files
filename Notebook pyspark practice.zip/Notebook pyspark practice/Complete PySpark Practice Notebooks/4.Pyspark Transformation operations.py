# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

#a sample DataFrame df with columns: "name", "age", and "country". 
# Create a sample DataFrame
data = [
    ("John", 25, "USA"),
    ("Jane", 30, "Canada"),
    ("Sam", 28, "USA"),
    ("Emily", 32, "Germany"),
    ("Mike", 29, "Canada")
]
schema = ["name", "age", "country"]
df = spark.createDataFrame(data, schema)

# COMMAND ----------

#Selecting specific columns using the select() method.
# Selecting specific columns
selected_df = df.select("name", "age")
selected_df.show()

# COMMAND ----------

#Filtering rows based on a condition using the filter() method.
# Filtering rows
filtered_df = df.filter(col("age") > 28)
filtered_df.show()

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

#Adding a new column based on a condition using the withColumn() method.
# Adding a new column
new_column_df = df.withColumn("age_category", when(col("age") < 30, "Young").otherwise("Old"))
new_column_df.show()

# COMMAND ----------

#Dropping a column using the drop() method.
# Dropping columns
dropped_column_df = df.drop("country")
dropped_column_df.show()

# COMMAND ----------

# Renaming columns
renamed_column_df = df.withColumnRenamed("name", "full_name")
renamed_column_df.show()

# COMMAND ----------

# Sorting by a column
sorted_df = df.sort("age")
sorted_df.show()

# COMMAND ----------

# Grouping and Aggregation
grouped_df = df.groupBy("country").agg({"age": "avg"})
grouped_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Grouping the DataFrame by a column and performing aggregation using the groupBy() and agg() methods.
# MAGIC
# MAGIC Grouping: Grouping involves dividing the DataFrame into groups based on one or more columns. It creates a GroupedData object that represents the grouped DataFrame. You can perform operations on the grouped DataFrame to calculate aggregate values for each group.
# MAGIC
# MAGIC Aggregation: Aggregation refers to the calculation of summary statistics or metrics for each group in a DataFrame. It allows you to perform various aggregate functions such as sum, count, average, minimum, maximum, etc. These functions are applied to specific columns of the grouped DataFrame using the agg() method.
# MAGIC
# MAGIC

# COMMAND ----------

# Distinct values
distinct_df = df.select("country").distinct()
distinct_df.show()

# COMMAND ----------

# Limiting the number of rows
limited_df = df.limit(3)
limited_df.show()

# COMMAND ----------

# Perform partitioning
df_partitioned = df.repartition(col("country"))
df_partitioned.write.partitionBy("country").parquet("partitioned_data.parquet")



# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

# Perform bucketing
df_bucketed = df_partitioned.withColumn("age_bucket", (col("age") / 5).cast(IntegerType()))
df_bucketed.write.bucketBy(4, "age_bucket").sortBy("name").parquet("bucketed_data.parquet")

# COMMAND ----------

# MAGIC %md
# MAGIC Partitioning:
# MAGIC
# MAGIC We use the repartition() method on the DataFrame to redistribute the data across partitions based on the "country" column.
# MAGIC We use the write.partitionBy() method to specify that the data should be written to separate partitions based on the "country" column when saving as Parquet format.
# MAGIC Bucketing:
# MAGIC
# MAGIC We use the withColumn() method to add a new column "age_bucket" to the DataFrame by dividing the "age" column by 5 and casting it to an integer.
# MAGIC We use the write.bucketBy() method to specify that the data should be bucketed into 4 buckets based on the "age_bucket" column.
# MAGIC We use the write.sortBy() method to specify the column to sort the data within each bucket (in this case, "name").
# MAGIC Finally, we save the DataFrame as Parquet format.
# MAGIC The resulting partitioned DataFrame is saved as "partitioned_data.parquet" with separate directories for each country. The bucketed DataFrame is saved as "bucketed_data.parquet" with data distributed into buckets based on the "age_bucket" column.
# MAGIC
# MAGIC Note: Partitioning and bucketing are optimization techniques used to improve query performance by organizing the data based on specific columns. The number of partitions and buckets, as well as the columns used for partitioning and bucketing, should be chosen based on the nature and size of the data and the expected query patterns.

# COMMAND ----------

