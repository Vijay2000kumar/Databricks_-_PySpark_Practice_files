# Databricks notebook source
# Create the first DataFrame
data1 = [
    (1, "John"),
    (2, "Jane"),
    (3, "Sam")
]
schema1 = ["id", "name"]
df1 = spark.createDataFrame(data1, schema1)

# COMMAND ----------

display(df1)

# COMMAND ----------


# Create the second DataFrame
data2 = [
    (1, "USA"),
    (2, "Canada"),
    (4, "Germany")
]
schema2 = ["id", "country"]
df2 = spark.createDataFrame(data2, schema2)

# COMMAND ----------

inner_df=df1.join(df2, df1.id==df2.id,'inner')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Inner Join: It selects the matching rows from both DataFrames based on the "id" column.

# COMMAND ----------

inner_df=df1.join(df2, df1.id==df2.id,'left')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Left Join: It selects all rows from the left DataFrame (df1) and the matching rows from the right DataFrame (df2).

# COMMAND ----------

# Right Join
inner_df=df1.join(df2, df1.id==df2.id,'right')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Right Join: It selects all rows from the right DataFrame (df2) and the matching rows from the left DataFrame (df1).

# COMMAND ----------

# Full  Join
inner_df=df1.join(df2, df1.id==df2.id,'full')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Full Outer Join: It selects all rows from both DataFrames, combining the matching rows based on the "id" column.

# COMMAND ----------

# Left Semi Join
inner_df=df1.join(df2, df1.id==df2.id,'left_semi')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Left Semi Join: It selects the rows from the left DataFrame (df1) that have a match in the right DataFrame (df2).

# COMMAND ----------

# Left Anti Join
inner_df=df1.join(df2, df1.id==df2.id,'left_anti')
inner_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Left Anti Join: It selects the rows from the left DataFrame (df1) that do not have a match in the right DataFrame (df2).

# COMMAND ----------

semijoins_df=df1.join(df2, on="id", how="cross").show()

# COMMAND ----------

df2.crossJoin(df1).count()

# COMMAND ----------

df1.count()

# COMMAND ----------

df2.count()

# COMMAND ----------

