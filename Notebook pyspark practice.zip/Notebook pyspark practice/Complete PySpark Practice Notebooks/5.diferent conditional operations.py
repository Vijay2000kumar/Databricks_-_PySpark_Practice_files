# Databricks notebook source
# MAGIC %md
# MAGIC demonstrates the usage of when(), otherwise(), case(), ifelse(), and else_() operations in PySpark:

# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

#create a SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# create a sample dataframe
data = [
    ("John", 25),
    ("Jane", 30),
    ("Sam", 28),
    ("Emily", 32),
    ("Mike", 29)
]

# COMMAND ----------

#create schema
schema = ["name", "age"]
df = spark.createDataFrame(data, schema)

# COMMAND ----------

#performing conditional transformations
df_transformed = df.withColumn("age_group",when (col("age")<30, "Young").when(col("age")>= 30,"Old").otherwise("Unknown"))

# COMMAND ----------

# Show the transformed DataFrames
df_transformed.show()

# COMMAND ----------

# Perform case transformation
df_case_transformed = df.withColumn("age_group",
    (when(col("age") < 25, "Below 25")
    .when((col("age") >= 25) & (col("age") <= 30), "25 to 30")
    .when(col("age") > 30, "Above 30")
    .otherwise("Unknown"))                                  )

# COMMAND ----------

df_case_transformed.show()

# COMMAND ----------

# Perform if-else transformation
df_ifelse_transformed = df.withColumn("age_group",
    (when(col("age") < 30, "Young")
    .otherwise("Old"))
)

# COMMAND ----------

df_ifelse_transformed.show()

# COMMAND ----------

# Perform distinct operation
df_distinct = df.distinct()
df_distinct.show()

# COMMAND ----------

# Perform sorting operation
df_sorted = df.orderBy("age")
df_sorted.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Distinct operation: We use the distinct() method on the DataFrame to remove duplicate rows and keep only the unique rows.
# MAGIC
# MAGIC Sorting operation: We use the orderBy() method on the DataFrame to sort the rows based on the "age" column in ascending order. By default, the sorting is done in ascending order, but you can specify desc("age") for descending order.
# MAGIC
# MAGIC The resulting DataFrames, df_distinct and df_sorted, are displayed using the show() method.

# COMMAND ----------

