# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# Create a sample DataFrame
data = [
    ("John", 25, "USA"),
    ("Jane", 30, "Canada"),
    ("Sam", 28, "USA"),
    ("Emily", 32, "Germany"),
    ("Mike", 29, "Canada")
]
schema = ["name", "age", "country"]
df = spark.createDataFrame(data, schema)

# COMMAND ----------

display(df)

# COMMAND ----------

# Equality filter
equality_filter = df.filter(col("country") == "USA")
equality_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Equality filter using the filter() method with the equality condition.

# COMMAND ----------

# Inequality filter
inequality_filter = df.filter(col("age") > 28)
inequality_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC < less then or / > greater then
# MAGIC Inequality filter using the filter() method with the inequality condition.

# COMMAND ----------

# Multiple conditions using logical operators
multiple_conditions_filter = df.filter((col("age") > 28) & (col("country") == "USA"))
multiple_conditions_filter.show()

# COMMAND ----------

# Multiple conditions using logical operators
multiple_conditions_filter = df.filter((col("age") > 24) & (col("country") == "USA"))
multiple_conditions_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Multiple conditions filter using logical operators (& for AND).

# COMMAND ----------

# Negation filter
negation_filter = df.filter(~(col("country") == "USA"))
negation_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Negation filter using the filter() method with the negation (~) operator.

# COMMAND ----------

# String pattern filter
pattern_filter = df.filter(col("name").like("%e%"))
pattern_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC String pattern filter using the like() function with a pattern matching condition.

# COMMAND ----------

# Null values filter
null_filter = df.filter(col("country").isNull())
null_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Null values filter using the isNull() function.

# COMMAND ----------

# Not-null values filter
not_null_filter = df.filter(col("country").isNotNull())
not_null_filter.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Not-null values filter using the isNotNull() function.

# COMMAND ----------

