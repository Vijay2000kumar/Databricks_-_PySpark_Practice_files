# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC start by importing the necessary modules from PySpark. We then create a SparkSession using the builder pattern.\
# MAGIC
# MAGIC
# MAGIC Builder - The builder pattern allows us to chain methods together and configure various settings before calling the getOrCreate() method to create the SparkSession instance. This approach provides a clear and concise way to build the SparkSession object with the desired configuration.

# COMMAND ----------

# Create a sample data list
data = [
    ("John", 25),
    ("Jane", 30),
    ("Sam", 28),
    ("Emily", 32),
    ("Mike", 29)
]


# COMMAND ----------

 '''define the schema for the DataFrame using the StructType and StructField classes, specifying the column names and types.'''
# Define the schema for the DataFrame
schema = StructType([
    StructField("name", StringType(), nullable=False),
    StructField("age", IntegerType(), nullable=False)
])

# COMMAND ----------

# Create the DataFrame
df = spark.createDataFrame(data, schema)

# COMMAND ----------

# Show the DataFrame
df.show()

# COMMAND ----------

#printing the schema using the printSchema() method, and accessing individual columns using square bracket notation.
# Print the schema of the DataFrame
df.printSchema()

# COMMAND ----------

from pyspark.sql import SparkSession

# COMMAND ----------

# MAGIC %md
# MAGIC creating another dataframe and perform different basics operatios

# COMMAND ----------

#create sparksession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# create a smple dataframe
data =[
    (1,"John", 25, 50000),
    (2,"Jane", 30, 50000),
    (3,"Sam", 28, 50000),
    (4,"Emily", 32, 50000),
    (5,"Mike", 29, 50000)
]

# COMMAND ----------

schema =["id","name","age","salary"]
df = spark.createDataFrame(data, schema)

# COMMAND ----------

#Selecting specific columns
df.select("name","salary").show()

# COMMAND ----------

#adding a new column
df.withColumn("bonus", df["salary"] * 0.1).show()

# COMMAND ----------

from pyspark.sql.functions import avg

# COMMAND ----------

df.filter avg("salary")

# COMMAND ----------

df.withColumn("vijay", df["age"] + 5).show()

# COMMAND ----------

# Renaming columns
df.withColumnRenamed("age","years_old").show()

# COMMAND ----------

# Droping columns
df.drop("bonus").show()

# COMMAND ----------

display(df)

# COMMAND ----------

# Filtering rows
df.filter(df["age"]>25).show()

# COMMAND ----------

# Sorting by a column
df.sort("age").show()

# COMMAND ----------

#Reordering columns
df.select("salary", "age", "name").show()

# COMMAND ----------

