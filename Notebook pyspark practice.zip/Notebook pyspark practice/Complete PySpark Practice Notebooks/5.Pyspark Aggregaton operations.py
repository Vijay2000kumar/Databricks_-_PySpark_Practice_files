# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, count, sum, max, min


# COMMAND ----------

# Create a SparkSession
spark = SparkSession.builder.getOrCreate()# Create a SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# Create a sample DataFrame
data = [
    ("John", 25, "USA"),
    ("Jane", 30, "Canada"),
    ("Sam", 28, "USA"),
    ("Emily", 32, "Germany"),
    ("Mike", 29, "Canada")
]
schema = ["name", "age", "country"]
df = spark.createDataFrame(data, schema)


# COMMAND ----------

# Aggregation operations
df_agg = df.select(
    count("name").alias("total_count"),
    avg("age").alias("average_age"),
    sum("age").alias("total_age"),
    max("age").alias("max_age"),
    min("age").alias("min_age")
)

# COMMAND ----------

# MAGIC %md
# MAGIC Count: We use the count() function to count the number of rows in the DataFrame.
# MAGIC
# MAGIC Average: We use the avg() function to calculate the average age.
# MAGIC
# MAGIC Sum: We use the sum() function to calculate the total age.
# MAGIC
# MAGIC Maximum: We use the max() function to find the maximum age.
# MAGIC
# MAGIC Minimum: We use the min() function to find the minimum age.

# COMMAND ----------

# Show the result
df_agg.show()

# COMMAND ----------

from pyspark.sql.functions import col, sumDistinct, mean, first, last, collect_list, collect_set



# COMMAND ----------

# aggregation operations
df_aggregate = df.select(
    sumDistinct("age").alias("sum_distinct_age"),
    mean("age").alias("mean_age"),
    first("name").alias("first_name"),
    last("name").alias("last_name"),
    collect_list("country").alias("countries_list"),
    collect_set("country").alias("countries_set")
)

# COMMAND ----------

#show the result
df_aggregate.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC we have a sample DataFrame df with columns: "name", "age", and "country". We perform the following aggregation operations:
# MAGIC
# MAGIC SumDistinct: We use the sumDistinct() function to calculate the sum of distinct age values.
# MAGIC
# MAGIC Mean: We use the mean() function to calculate the average age.
# MAGIC
# MAGIC First: We use the first() function to retrieve the first name value.
# MAGIC
# MAGIC Last: We use the last() function to retrieve the last name value.
# MAGIC
# MAGIC CollectList: We use the collect_list() function to collect all the country values into a list.
# MAGIC
# MAGIC CollectSet: We use the collect_set() function to collect all the unique country values into a set.
# MAGIC
# MAGIC The result of these aggregation operations is stored in a new DataFrame df_agg, where each aggregation is given an appropriate alias using the alias() method.
# MAGIC
# MAGIC Finally, we display the result using the show() method with truncate=False to show the complete values.

# COMMAND ----------

