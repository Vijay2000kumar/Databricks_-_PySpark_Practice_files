# Databricks notebook source
# MAGIC %md
# MAGIC aggregate functions 𝗮𝗽𝗽𝗿𝗼𝘅_𝗰𝗼𝘂𝗻𝘁_𝗱𝗶𝘀𝘁𝗶𝗻𝗰𝘁(), 𝗮𝘃𝗴(), 𝗰𝗼𝗹𝗹𝗲𝗰𝘁_𝗹𝗶𝘀𝘁(), 𝗰𝗼𝗹𝗹𝗲𝗰𝘁_𝘀𝗲𝘁(), 𝗰𝗼𝘂𝗻𝘁𝗗𝗶𝘀𝘁𝗶𝗻𝗰𝘁(), 𝗰𝗼𝘂𝗻𝘁() in pyspark.
# MAGIC - Aggregate functions operate on a group of rows and calculate a single return value for every group.
# MAGIC - approx_count_distinct() - returns the count of distinct items in a group of rows.
# MAGIC - avg() - returns average of values in a group of rows.
# MAGIC - collect_list() - returns all values from input column as list[] with duplicates.
# MAGIC - collect_set() - returns all values from input column as list[] without duplicates.
# MAGIC - countDistinct() - returns number of distinct elements in input column.
# MAGIC - count() - return number of elements in a column.

# COMMAND ----------

simpleData = [("Maheer","HR",1500),
        ("Wafa","IT",3000),
        ("Asi","HR",1500)]
schema = ["employee_name", "department","salary"]
df = spark.createDataFrame(data=simpleData, schema = schema)
df.show()

# COMMAND ----------

# approx_count_distinct(), avg()

from pyspark.sql.functions import approx_count_distinct, avg
df.select(approx_count_distinct(col='salary')).show()

df.select(avg(col='salary')).show()

# COMMAND ----------

# collect_list(), collect_set()

from pyspark.sql.functions import collect_list, collect_set
df.select(collect_list(df.salary)).show()

df.select(collect_set(df.salary)).show()

# COMMAND ----------

# count_distinct(), count()

from pyspark.sql.functions import count_distinct, count
df.select(count_distinct(df.salary)).show()

df.select(count(col='salary')).show()

# COMMAND ----------

