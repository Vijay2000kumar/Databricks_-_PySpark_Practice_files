# Databricks notebook source
#𝗔𝗿𝗿𝗮𝘆𝗧𝘆𝗽𝗲 Columns in PySpark
#1 Create a dataframe with ArrayType column

data = [('abc',[1,2,3]),('mno',[3,4,4]),('xyz',[5,6,6])]
schema = ['id','numbers']

df = spark.createDataFrame(data=data,schema=schema)

# COMMAND ----------

df.show()
df.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,ArrayType


# COMMAND ----------

data = [('abc',[1,2,3]),('mno',[3,4,4]),('xyz',[5,6,6])]
schema = StructType([\
           StructField('id', StringType()),\
           StructField('numbers',ArrayType(IntegerType()))])


# COMMAND ----------

df1 = spark.createDataFrame(data=data,schema=schema)
df1.show()
df1.printSchema()

# COMMAND ----------

#2 Fetch value from Array as new column

df1.withColumn('firstnumber', df1.numbers[0]).show()

# COMMAND ----------

#3 Combine columns to Array

data = [(1,2),(3,4)]
schema = ['num1','num2']

df = spark.createDataFrame(data=data,schema=schema)
df.show()

# COMMAND ----------

from pyspark.sql.functions import col,array
data = [(1,2),(3,4)]
schema = ['num1','num2']

df = spark.createDataFrame(data=data,schema=schema)
df1 = df.withColumn('numbers',array(col('num1'),col('num2')))
df1.show()
df1.printSchema()

# COMMAND ----------

