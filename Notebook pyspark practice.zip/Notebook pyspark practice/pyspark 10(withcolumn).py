# Databricks notebook source
# MAGIC %md
# MAGIC Add new column, change data or data type of existing column using 𝘄𝗶𝘁𝗵𝗖𝗼𝗹𝘂𝗺𝗻() function in PySpark.

# COMMAND ----------

from pyspark.sql.functions import col
data = [(1,'Maheer','3000'),(2,'Wafa','4000')]
columns = ['id','name','salary']
df = spark.createDataFrame(data=data,schema=columns)

# COMMAND ----------

df.show()
df.printSchema()

# COMMAND ----------

# Change column DataType
df1 = df.withColumn(colName='salary',col=col('salary').cast('Integer'))

# COMMAND ----------

df1.show()
df1.printSchema()

# COMMAND ----------

# Update value of existing column

from pyspark.sql.functions import col
df2 = df1.withColumn(colName='salary',col=col('salary')*2)
df2.show()

# COMMAND ----------

# Create a new column with new data

from pyspark.sql.functions import col , lit
df3 = df2.withColumn('country',lit('India'))
df3.show()

# COMMAND ----------

# Create a new column with existing data

from pyspark.sql.functions import col , lit
df4= df3.withColumn('copiedsalary',col('salary')*(-1))
df4.show()

# COMMAND ----------

