# Databricks notebook source
# MAGIC %md
# MAGIC Explained about 𝗲𝘅𝗽𝗹𝗼𝗱𝗲() , 𝘀𝗽𝗹𝗶𝘁(), 𝗮𝗿𝗿𝗮𝘆() & 𝗮𝗿𝗿𝗮𝘆_𝗰𝗼𝗻𝘁𝗮𝗶𝗻𝘀() functions usages with ArrayType column in PySpark.

# COMMAND ----------

# explode() - Use to create a new row for each element in the given array column.
data = [(1,'Maheer',['dotnet','azure']),(2,'Wafa',['java','aws'])]
schema = ['id', 'name', 'skills']

# COMMAND ----------


df = spark.createDataFrame(data=data,schema=schema)
df.display()
df.printSchema()

# COMMAND ----------


from pyspark.sql.functions import explode,col
df1 = df.withColumn('skill',explode(col='skills'))
df1.show()

# COMMAND ----------

# split() - SQL function return an array type after splitting the string column by delimiter.

data = [(1,'Maheer','dotnet,azure'),(2,'Wafa','java,aws')]
schema = ['id', 'name', 'skills']


# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.display()
df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import split,col
df1 = df.withColumn('skills_array',split('skills',','))
df1.show()

# COMMAND ----------

# array() - Use array function to create a new array column by merging the data from multiple columns.

data = [(1,'Maheer','dotnet','azure'),(2,'Wafa','java','aws')]
schema = ['id', 'name', 'primaryskill', 'secondaryskill']


# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.display()
df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import array,col
df1 = df.withColumn('skillsArray',array(col('primarySkill'),col('secondarySkill')))
df1.show()

# COMMAND ----------

# array_contains() - sql fuction is used to check if array column contains a value. Returns "null" if the array is null, "true" if the array contains the value and "false" otherwise.

data = [(1,'Maheer',['dotnet','azure']),(2,'Wafa',['java','aws'])]
schema = ['id', 'name', 'skills']

# COMMAND ----------

df = spark.createDataFrame(data=data,schema=schema)
df.display()
df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import array_contains,col

df1 = df.withColumn('HasJavaSkill',array_contains('skills',value='java'))
df1.show()

# COMMAND ----------

