# Databricks notebook source
# to see sample dataset
display(dbutils.fs.ls('/databricks-datasets'))

# COMMAND ----------

f = open("dbfs:/databricks-datasets/README.md", 'r')
print(f.read())

# COMMAND ----------

CREATE TABLE default.people10m OPTIONS (PATH 'dbfs:/databricks-datasets/learning-spark-v2/people/people-10m.delta')

# COMMAND ----------

# MAGIC %fs ls "/databricks-datasets/songs/data-001"

# COMMAND ----------

# MAGIC %fs head --maxBytes=10000 "/databricks-datasets/songs/README.md"

# COMMAND ----------

# MAGIC %fs head --maxBytes=10000 "/databricks-datasets/songs/data-001/part-00000"

# COMMAND ----------

df = spark.read.format('csv')\
    .option('header',True).option("sep", "\t").load('dbfs:/databricks-datasets/songs/data-001/part-00000')\
        .select('*','_metadata')
df.display()

# COMMAND ----------

spark.readStream \
  .format("cloudFiles") \
  .option("cloudFiles.format", "csv") \
  .schema(schema) \
  .load("abfss://my-bucket/csvData") \
  .selectExpr("*", "_metadata as source_metadata") \
  .writeStream \
  .format("delta") \
  .option("checkpointLocation", checkpointLocation) \
  .start(targetTable)

# COMMAND ----------

from pyspark.sql.types import DoubleType, IntegerType, StringType, StructType, StructField


# COMMAND ----------

# Define variables used in the code below
file_path = "/databricks-datasets/songs/data-001/"
table_name = "raw_song_data"
checkpoint_path = "dbfs:/dbfs/tmp/pipeline_get_started/_checkpoint/song_data"


# COMMAND ----------

schema = StructType(
  [
    StructField("artist_id", StringType(), True),
    StructField("artist_lat", DoubleType(), True),
    StructField("artist_long", DoubleType(), True),
    StructField("artist_location", StringType(), True),
    StructField("artist_name", StringType(), True),
    StructField("duration", DoubleType(), True),
    StructField("end_of_fade_in", DoubleType(), True),
    StructField("key", IntegerType(), True),
    StructField("key_confidence", DoubleType(), True),
    StructField("loudness", DoubleType(), True),
    StructField("release", StringType(), True),
    StructField("song_hotnes", DoubleType(), True),
    StructField("song_id", StringType(), True),
    StructField("start_of_fade_out", DoubleType(), True),
    StructField("tempo", DoubleType(), True),
    StructField("time_signature", DoubleType(), True),
    StructField("time_signature_confidence", DoubleType(), True),
    StructField("title", StringType(), True),
    StructField("year", IntegerType(), True),
    StructField("partial_sequence", IntegerType(), True)
  ]
)


# COMMAND ----------


metadata=(spark.readStream
  .format("cloudFiles")
  .schema(schema)
  .option("cloudFiles.format", "csv")
  .option("sep","\t")
  .load('/databricks-datasets/songs/data-001/')
  .selectExpr("*", "_metadata as source_metadata") 
  .writeStream
  .option("checkpointLocation", 'dbfs:/dbfs/tmp/pipeline_get_started/_checkpoint/song_data')
  .trigger(availableNow=True)
  .toTable('raw_song_data')
)

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE
# MAGIC   prepared_raw_song_data (
# MAGIC     artist_id STRING,
# MAGIC     artist_name STRING,
# MAGIC     duration DOUBLE,
# MAGIC     release STRING,
# MAGIC     tempo DOUBLE,
# MAGIC     time_signature DOUBLE,
# MAGIC     title STRING,
# MAGIC     year DOUBLE,
# MAGIC     processed_time TIMESTAMP
# MAGIC   );

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO
# MAGIC   prepared_raw_song_data
# MAGIC SELECT
# MAGIC   artist_id,
# MAGIC   artist_name,
# MAGIC   duration,
# MAGIC   release,
# MAGIC   tempo,
# MAGIC   time_signature,
# MAGIC   title,
# MAGIC   year,
# MAGIC   current_timestamp()
# MAGIC FROM
# MAGIC   raw_song_data

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Which artists released the most songs each year?
# MAGIC SELECT
# MAGIC   artist_name,
# MAGIC   count(artist_name)
# MAGIC AS
# MAGIC   num_songs,
# MAGIC   year
# MAGIC FROM
# MAGIC   prepared_raw_song_data
# MAGIC WHERE
# MAGIC   year > 0
# MAGIC GROUP BY
# MAGIC   artist_name,
# MAGIC   year
# MAGIC ORDER BY
# MAGIC   num_songs DESC,
# MAGIC   year DESC

# COMMAND ----------

# MAGIC  %sql
# MAGIC  -- Find songs for your DJ list
# MAGIC  SELECT
# MAGIC    artist_name,
# MAGIC    title,
# MAGIC    tempo
# MAGIC  FROM
# MAGIC    prepared_raw_song_data
# MAGIC  WHERE
# MAGIC    time_signature = 4
# MAGIC    AND
# MAGIC    tempo between 100 and 140;

# COMMAND ----------

