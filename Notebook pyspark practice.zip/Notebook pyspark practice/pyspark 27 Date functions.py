# Databricks notebook source
# MAGIC %md
# MAGIC Date functions in PySpark :-
# MAGIC - DateType default format is 𝘆𝘆𝘆𝘆-𝗠𝗠-𝗱𝗱
# MAGIC - 𝗰𝘂𝗿𝗿𝗲𝗻𝘁_𝗱𝗮𝘁𝗲() get the current system date. By default, the data will be returned in yyyy-MM-dd format.
# MAGIC - 𝗱𝗮𝘁𝗲_𝗳𝗼𝗿𝗺𝗮𝘁() to parses the date and converts from yyyy-MM-dd to specified format.
# MAGIC - 𝘁𝗼_𝗱𝗮𝘁𝗲() converts date string in to DateType.we need to specify format of date in the string in the function.

# COMMAND ----------

df=spark.range(2)
df.show()

# COMMAND ----------

# datetype default format yyyy-MM-dd
# gives current date in yyyy-MM-dd format

from pyspark.sql.functions import current_date
df1 = df.withColumn('currentDate',col=current_date())
df1.show()
df1.printSchema()

# COMMAND ----------

# converts yyyy-MM-dd datetype to specified format
from pyspark.sql.functions import date_format

df2 = df1.withColumn('Date_New_Format',date_format(df1.currentDate,'MM.yyyy.dd'))

# COMMAND ----------

# gives Date_New_Format in string datatype
df2.show()
df2.printSchema()

# COMMAND ----------

# converts string values of date to DateType
# DateType default format yyyy-MM-dd
from pyspark.sql.functions import to_date
df3 = df2.withColumn('Date_in_DateType', to_date(df2.Date_New_Format,'MM.yyyy.dd'))
df3.show()
df3.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 𝗱𝗮𝘁𝗲𝗱𝗶𝗳𝗳(), 𝗺𝗼𝗻𝘁𝗵𝘀_𝗯𝗲𝘁𝘄𝗲𝗲𝗻(), 𝗮𝗱𝗱_𝗺𝗼𝗻𝘁𝗵𝘀(), 𝗱𝗮𝘁𝗲_𝗮𝗱𝗱(), 𝗺𝗼𝗻𝘁𝗵() & 𝘆𝗲𝗮𝗿() functions which are useful to work with dates in pyspark.

# COMMAND ----------

from pyspark.sql.functions import datediff

df = spark.createDataFrame([('1999-06-02','1995-07-01')],['d1','d2'])
df.show()

# COMMAND ----------

# datediff() - difference between the startdate and enddate
df.withColumn('datediff',datediff(end='d2',start='d1')).show()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# months_between()- returns number of months between dates date1 and date2
df.withColumn('monthsbetween',months_between(date1='d2',date2='d1')).show()

# COMMAND ----------

# add_months()- return a date with a specified number of months added or subtracted to it
df.withColumn('addmonths',add_months(start='d2',months=3)).show()
df.withColumn('subtractmonths',add_months(start='d2',months=-3)).show()

# COMMAND ----------

# date_add()- the number of days to be added or subtracted
df.withColumn('daysadd',date_add(start='d2',days=10)).show()
df.withColumn('daysSubtract',date_add(start='d2',days=-10)).show()

# COMMAND ----------

# year()- Extracting the year from Date
df.withColumn('year',year(col='d2')).show()

# COMMAND ----------

# month()- Extracting the month from Date
df.withColumn('month',month(col='d2')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC 𝗧𝗶𝗺𝗲𝘀𝘁𝗮𝗺𝗽 𝗳𝘂𝗻𝗰𝘁𝗶𝗼𝗻𝘀 𝗰𝘂𝗿𝗿𝗲𝗻𝘁_𝘁𝗶𝗺𝗲𝘀𝘁𝗮𝗺𝗽(), 𝘁𝗼_𝘁𝗶𝗺𝗲𝘀𝘁𝗮𝗺𝗽(), 𝗵𝗼𝘂𝗿(), 𝗺𝗶𝗻𝘂𝘁𝗲(), 𝘀𝗲𝗰𝗼𝗻𝗱() -
# MAGIC - TimestampType default format is 𝘆𝘆𝘆𝘆-𝗠𝗠-𝗱𝗱 𝗛𝗛:𝗺𝗺:𝘀𝘀.𝗦𝗦𝗦𝗦
# MAGIC - current_timestamp() get the current timestamp. By default, the data will be returned in default format.
# MAGIC - to_timestamp() converts timestamp string in to TimestampType. We need to specify format of timestamp in the string in the function.
# MAGIC - hour(), minute(), second() functions. 

# COMMAND ----------

df = spark.range(2)
df.show()

# COMMAND ----------

# current_timestamp()
from pyspark.sql.functions import current_timestamp


# COMMAND ----------

df1 = df.withColumn('currentTimeStamp',current_timestamp())
df1.show(truncate= False)
df1.printSchema()

# COMMAND ----------

# Converts timestamp string into TimestampType

from pyspark.sql.functions import lit, to_timestamp
df2 = df1.withColumn('timestanpInString',lit('12.25.2023 08.10.03'))
df2.show(truncate=False)
df2.printSchema()

# COMMAND ----------

# to_timestamp()
from pyspark.sql.functions import to_timestamp
df3 = df2.withColumn('timeStanpType',to_timestamp(col=df2.timestanpInString,\
                        format='MM.dd.yyyy HH.mm.ss'))
df3.show(truncate=False)
df3.printSchema()

# COMMAND ----------

# hour(), minute(), second()
from pyspark.sql.functions import hour , minute, second
df4 = df1.select('*',hour('currentTimeStamp').alias('hour'),\
         minute('currentTimeStamp').alias('minute'),\
         second('currentTimeStamp').alias('second'))
df4.show(truncate=False)
df4.printSchema()

# COMMAND ----------

